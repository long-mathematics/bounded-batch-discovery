# Revision log — 12 November 2026

This version revises the 21-page consolidated draft. The original source has not
been overwritten. The revised manuscript is 27 pages and contains 14 references.
The proof checks are internal; they are not formal verification or independent
peer review.

## Mathematical additions and corrections

| Location in revised PDF | Change |
|---|---|
| Lemma 2.2 | Makes the finite-family, coordinate-truncation, bounded-function, and monotone-limit steps explicit. |
| Proposition 3.2 | Adds the signed-weight variance bound with conditional mean batch size kappa_i. No uniform cardinality bound is required. |
| Proposition 3.4 | Adds general fractional-allocation Bennett bounds, including the supported maximum batch sizes B_i. Explains why this is support-sensitive, not necessarily improved by rarity alone. |
| Proposition 4.2 | Gives an explicit hub construction showing sharpness of L_B for the specified worst-case coefficient-load method. Does not claim optimality of Var(Q)/E(Q). |
| Lemmas 5.3–5.4 and Theorem 5.5 | Proves the logarithmic Kolmogorov bound C[(B^2/V) log(e+V/B^2)]^(1/4). Includes conditional Gaussian smoothing, stopping, deterministic-bracket completion, and the fixed-p=3 Haeusler argument. |
| Propositions/Lemmas 7.2–7.3 | Generalizes variance equivalence to fixed laws with finite second batch-size moment, and the window lemma to summable marginal rates with the stated variance assumptions. |
| Proposition 7.5 | Specifies the exact Boucheron–Lugosi–Massart lower-tail result and includes the original 2000 reference. |
| Theorem 8.1 and Corollary 8.2 | Adds the unbounded-batch Lindeberg theorem for Poissonized triangular arrays and the fixed-law, fixed-sample corollary. Both terms in the compound-Poisson second moment are controlled. |
| Example 8.3 | Gives an integer-block counterexample with finite second moment, variance divergence for all times, and a non-Gaussian two-point subsequential limit. Explains loss of second moment in the weak limit. |
| Proposition 9.1 | Replaces the former coarse bound by log E exp(theta M) <= V theta^2/[2(1-2B abs(theta))] and the tail bound 2 exp(-x^2/[2(V+2Bx)]). |
| Remark 9.2 | Retains the correction to the proposed near-Gaussian range: epsilon V/(2B), not a square-root-epsilon range. |
| Theorem 10.2 and Corollary 10.3 | Replaces the exponential-in-r bracket constant by min(2^(2r-1), e^2 r), with d_1=1. Gives growing-threshold CLTs and corresponding quantitative rates. Fixed-r moderate deviations remain explicitly scoped. |
| Section 11 | Propagates the improved bound to weighted and conditional discovery results. |
| Appendix A | Supplies an explicit threshold Lipschitz constant 2B^2 and separately proves stopped-grid convergence, without treating grid increments as bounded jumps. |
| Appendix B | Replaces the previous reconciliation record by a current proof/reproducibility audit. |

## References and attribution

All cited keys resolve. The bibliography adds Boucheron–Lugosi–Massart (2000),
Esary–Proschan–Walkup (1967), and Good–Toulmin (1956). The Dembo–Zeitouni edition
is specified as the corrected printing of the second edition. Exact theorem
locators are provided for the external results used. Standard stopping and
augmentation ideas are distinguished from the supplied model-specific argument.
See `reference_audit.md` for sources checked and access limitations.

## Validation

The original finite-state suite was rerun successfully. The new suite checks
signed variance, fractional and actual-variance moment bounds, threshold
envelopes, hub loads, the Holder algebra, and the counterexample parameters.
Numerical checks supplement the proofs; they do not establish asymptotic results.
The final PDF has no undefined citations or references, duplicate labels, or
LaTeX box warnings. All pages were rendered and inspected, including the revised
proofs and the separate references page.

## Not asserted

No optimal O(B/sqrt(V)) Kolmogorov rate, unrestricted finite-second-moment CLT,
fixed-sample triangular-array theorem, fixed-sample moderate-deviation principle,
relative Gaussian-tail approximation, exact-frequency joint CLT, functional CLT,
or unknown-law prediction interval is claimed.
