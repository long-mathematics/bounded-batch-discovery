# Proof audit summary — revised version

## Core conclusion

The bounded-batch discovery CLT and its fixed-law de-Poissonization are retained.
No unresolved proof obligation has been identified in the statements retained
in this revision. This assessment is an internal audit, not independent peer
review or formal verification.

## Dependency chain

1. Independent Poisson batch-type coordinates give exact discovery covariances.
2. Product-space variance drop and fractional Holder control bounded overlap;
   countable-coordinate limits are explicit.
3. The terminal martingale bracket has a nonnegative pair decomposition. Its
   coefficient load is at most L_B=B(4B-3)/2. This implies both bracket variance
   and exponential-moment bounds.
4. Haeusler's inequality, in the exact formulation stated by Mourrat, gives the
   fourth-moment normal-approximation bound after the deterministic-grid limit.
5. Stopping, Gaussian completion and the conditional smoothing lemma improve
   the rate to C[(B^2/V) log(e+V/B^2)]^(1/4). The stopped-grid limit is separately
   justified; the proof never bounds all grid increments by a single-jump bound.
6. Holder applied to the exponential martingale and bracket MGF gives the actual-
   variance Bernstein inequality with denominator 2(V+2Bx).
7. The fixed-law variance expansion, derivative estimate and monotone window
   coupling give the fixed-sample CLT with its actual variance. These transfer
   steps extend to finite-second-moment unbounded laws.
8. Large-batch truncation under the stated Lindeberg condition controls the full
   second moment of deleted incidence mass. It yields the unbounded Poissonized
   theorem, and then the fixed-law fixed-sample corollary.
9. Threshold integrands admit the improved linear-in-r envelope. Full Poisson
   paths, not only first arrival clocks, are the independent coordinates.
10. Nonnegative weighted discoveries and conditional future counts inherit the
    appropriate uniform results. Signed weights inherit the variance inequality,
    not automatically an actual-variance CLT.

## Important qualifications preserved

- The per-species maximum B_i is support-sensitive, not an averaged rarity measure.
- L_B is sharp for the specified coefficient-load calculation, not proved to be
  the optimal possible bracket-variance constant.
- The near-Gaussian range is linear in epsilon; the previously proposed
  square-root-epsilon range is rejected and a Bernoulli obstruction is given.
- The absolute variance expansion subtracts n f(n)^2, which need not tend to zero.
- The finite-second-moment counterexample has a weak limit of variance below one;
  rare large blocks destroy uniform integrability of normalized squares.
- The unbounded-batch Lindeberg condition is sufficient, not claimed necessary.
- Moderate deviations mean logarithmic Gaussian probabilities, not relative
  Gaussian-tail equivalence. No fixed-sample MDP is obtained by a mere CLT coupling.
- Covariance convergence and separate scalar CLTs do not prove joint or process
  limits, or permit subtraction to obtain exact-frequency CLTs.

## Checks

Both bundled scripts were run successfully. The first suite checks 40 bracket
cases, 25 fixed-sample cases and 80 MGF cases; its largest bracket identity
error is 4.4918291308704283e-11. The revision suite checks 108 signed variance,
144 fractional MGF, 288 actual-variance MGF, 30 hub-load, 5,000 Holder-parameter,
117,160 threshold-envelope, and 9 counterexample-parameter cases. These counts
are the actual executed checks, not claims of mathematical coverage.

Compilation and visual validation are recorded in `validation_report.json`.
The manuscript has 14 bibliography entries with no missing or unused citation
keys. `reference_audit.md` records direct theorem checks separately from metadata
and contextual checks, including access limitations.
