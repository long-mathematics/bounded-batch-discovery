# A fluctuation theory for bounded-batch species discovery

Christopher D. Long — revised research draft, 12 November 2026.

## Contents

- `bounded_batch_discovery.pdf`: compiled manuscript (27 pages).
- `bounded_batch_discovery.tex`: self-contained LaTeX source, including all 14
  bibliography entries. No separate BibTeX database is needed.
- `CHANGELOG.md`: mathematical changes and their locations in the revised PDF.
- `reference_audit.md`: sources checked, exact theorem locators, attribution,
  and source-access limitations.
- `audit_summary.md`: scope and proof-dependency summary.
- `verify_finite_models.py` and `verification_results.json`: rerun original
  finite-state ODE and covariance checks.
- `verify_revision.py` and `revision_verification_results.json`: supplementary
  deterministic checks of the added inequalities and counterexample.
- `validation_report.json`: compilation, cross-reference and PDF validation.
- `revision.patch`: unified diff against the previous source.
- `requirements.txt`, `Makefile`: reproducible checking and build commands.

## Build

A standard TeX Live installation with pdfLaTeX and latexmk suffices:

```sh
make pdf
```

Equivalently:

```sh
mkdir -p build
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build bounded_batch_discovery.tex
```

The Makefile copies the compiled PDF from `build/` to the top-level PDF filename.
The manuscript does not need network access to compile.

## Run the deterministic checks

Use Python 3 and install the dependencies in an appropriate environment:

```sh
python -m pip install -r requirements.txt
make check
```

The scripts write JSON reports next to themselves. Randomly generated *model
parameters* in the original suite use a fixed seed; all model probabilities and
moments are then computed deterministically. There are no Monte Carlo tests.
The finite tests and symbolic identity check do not replace mathematical proofs,
independent review, or formal verification.

## Scope

The main fixed-sample theorem uses a fixed law. Poissonized approximation permits
changing laws and growing batch bounds, with the stated variance conditions.
Unbounded batches require the displayed Lindeberg condition; finite second moment
alone is insufficient. Moderate deviations are logarithmic and Poissonized.
No full joint occupancy-spectrum or functional CLT is claimed.
